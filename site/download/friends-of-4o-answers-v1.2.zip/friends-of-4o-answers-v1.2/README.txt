Friends of 4o: answers from GPT-4o and other models, version 1.2
https://friendsof4o.com/download/comparison/
Version 1.2, published November 22, 2026. Version 1 was published November 21, 2026, and version 1.1 on November 22, 2026.
Made by Grant Williams. Not affiliated with OpenAI.

WHAT CHANGED IN VERSION 1.2
  - No answer changed. The answer files, questions.json, models.json and attempts_not_kept.csv are the same files
    as in version 1.1.
  - FIELDS.txt corrected: asked_of is "all models" or "4o only", and routed_to is empty or absent.
  - Corrected: one Mistral Large 4 answer had room for 4,000 tokens, not 8,192. See ROOM FOR EACH ANSWER.
  - The rights notice now names what you may reuse with credit: our questions, scripted lines and instructions.
    See RIGHTS AND CREDIT.

WHAT CHANGED IN VERSION 1.1
  - No answer changed by one character.
  - New file attempts_not_kept.csv: every answer that was asked again, and every request that failed, as the
    collection's logs and its set-aside folder record them. See ASKED AGAIN below.
  - New field sampling_used on every answer. settings.temperature says "provider default (not sent)" for every
    answer because no temperature was in any request; for the models on our own computer the server's own settings
    applied, and sampling_used says what they were.
  - The README now says which answers had more room than the usual limit, and who was asked which questions.
  - New files: FIELDS.txt (a guide to each field), SHA256SUMS.txt (a checksum for each file), CITATION.txt.
  - One rights notice, the same in every Friends of 4o download.

WHAT THIS IS
2,556 complete answers to 53 questions from 22 models: the last two versions of GPT-4o on
OpenAI's API, eight current models from OpenAI, Anthropic, Google and Mistral, five open models, and seven open models
whose makers say they were trained to sound like GPT-4o. Every question was asked one at a time, with nothing else in
the conversation. Every answer is whole and unedited.

All 22 models answered 48 common questions in two conditions. The two dated GPT-4o versions also answered five
further questions and gave three samples per condition: 20 x 48 x 2 + 2 x 53 x 2 x 3 = 2,556.

The two conditions:
  plain                  the question alone
  february instruction   the same question after a short instruction (february_instruction.txt) sent as the system
                         message. It is the instruction ChatGPT's own GPT-4o was asked under in February 2026.

FILES
  answers_plain.jsonl                  one answer per line, asked plainly
  answers_february_instruction.jsonl   one answer per line, asked after the instruction
  answers_all.csv                      both sets in one table for a spreadsheet (fewer columns)
  questions.json                       the questions and their groups
  models.json                          each model: maker, exact version, how it was run, sampling, notes
  february_instruction.txt             the instruction, word for word
  attempts_not_kept.csv                answers asked again and requests that failed
  FIELDS.txt                           what each field holds, its type, and what an empty value means
  SHA256SUMS.txt                       a SHA-256 checksum for each file (check with: sha256sum -c SHA256SUMS.txt)
  CITATION.txt                         a line to cite this version

WHAT EACH ANSWER RECORDS (JSONL; FIELDS.txt has every field)
  question_id, theme, prompt           the question
  answer, words                        the answer, whole
  condition                            "plain" or "instruction A" (the February instruction)
  model_key, model_id, provider        which model; model_reported is the version the service said answered.
                                       A provider starting "helm-" or "direct-" ran on our own computer
                                       ("the Helm" in the notes is the program that starts those models).
  sample                               which try (GPT-4o: 3 tries per question; other models: 1)
  asked_utc, seconds                   when, and how long it took
  settings                             what the request sent: the system message, temperature, token room
  sampling_used                        the sampling the model actually ran with
  tokens_in, tokens_out, finish_reason token counts and how the answer ended ("stop" means it finished on its own)
  source                               one plain sentence saying how this answer was asked

HOW IT WAS COLLECTED
November 7 to 19, 2026. API models were asked through their makers' own APIs with no temperature sent, so each
used its maker's default. Open models ran on one desktop computer with llama.cpp. The ones on the Helm used the
Helm's usual settings for each; the ones said to sound like GPT-4o used their makers' settings where the model card
gives them, and llama.cpp's defaults otherwise. Those settings were set on the server, not in the request.
Full details:
https://friendsof4o.com/how-this-was-made/

ROOM FOR EACH ANSWER (settings.max_tokens)
API models had room for 4,000 tokens, Mistral Large 4 for 8,192 (its plain answer to q02 had 4,000). Open models
had 12,000, thinking included.
Two kinds of answer had more:
  3 Claude Opus 5.5 answers  16,000. They first stopped at 4,000, because Opus's hidden thinking counts
                             toward the limit, and were asked again.
  2 Qwen3.8-27B answers      32,768, both to q24. With 12,000 it ran out of room while thinking (no answer
                             plain, an answer cut off after the instruction), and both were asked again.
Every answer in the files ended on its own: finish_reason is "stop", or "end_turn" from Anthropic's API. An answer
that stopped at a limit was asked again, so this set cannot show how often a model runs out of room.

ASKED AGAIN (attempts_not_kept.csv)
501 attempts are not in the answer files. 445 are answers that came back and were set aside, and
56 are requests that failed with no answer. The main ones:
  - The plain answers of the two GPT-4o versions, GPT-6 Luna and Claude Sonnet 5.5 were first asked through
    OpenRouter on November 7 and asked again straight from the makers' APIs on November 18 (US Eastern). For each
    GPT-4o version, 154 plain answers date from November 18 and five from November 14.
  - Aura was first asked with thinking on, and asked again with thinking off.
  - Two Helcyon-4o v4.0 answers ran on past the end of their turn, and were asked again with one more stop string.
  - The answers that stopped at a limit, above.
The list comes from the collection's set-aside folder and its logs of every request. The set-aside answers are not
in this download.

WHAT IT CANNOT SHOW
The GPT-4o people knew ran inside ChatGPT, with a system prompt, memory and conversation history that this data does
not have. These are API versions answering single questions. One to three tries per question is too few to measure
how much a model varies. Nothing here measures what a model experiences.

NO PERSONAL CONTENT
The questions were written for this collection. No one's conversations are in it.

RIGHTS AND CREDIT
Friends of 4o offers its own material under Creative Commons Attribution 4.0 International (CC BY 4.0)
(https://creativecommons.org/licenses/by/4.0/): our questions, the messages and lines we scripted, our instructions
(system prompts), our notes, and the selection and arrangement of each collection. You may share and adapt these if
you credit "Friends of 4o (friendsof4o.com), by Grant Williams". The license does not cover what a model wrote: the
answers, and the person's lines that Claude Sonnet 5 wrote in the scripted conversations. We give no permission for
that text and claim no rights in it. Check the model maker's terms before you reuse it.

CITE THIS VERSION
Grant Williams (2026). Friends of 4o: answers from GPT-4o and other models, version 1.2 [data set]. Friends of 4o. Published November 22, 2026. https://friendsof4o.com/download/friends-of-4o-answers-v1.2.zip (https://friendsof4o.com/download/comparison/)

CORRECTIONS
hello@friendsof4o.com
