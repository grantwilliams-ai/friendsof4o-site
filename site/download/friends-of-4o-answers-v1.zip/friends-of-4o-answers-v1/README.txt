Friends of 4o: answers from GPT-4o and other models, version 1
https://friendsof4o.com/download/comparison/
Made by Grant Williams. Not affiliated with OpenAI.

WHAT THIS IS
2,556 complete answers to 53 questions from 22 models: the last two versions of GPT-4o on
OpenAI's API, eight current models from OpenAI, Anthropic, Google and Mistral, five open models, and seven open models
whose makers say they were trained to sound like GPT-4o. Every question was asked one at a time, with nothing else in
the conversation. Every answer is whole and unedited.

Each model was asked two ways:
  plain                  the question alone
  february instruction   the same question after a short instruction (february_instruction.txt) sent as the system
                         message. It is the instruction ChatGPT's own GPT-4o was asked under in February 2026.

FILES
  answers_plain.jsonl                  one answer per line, asked plainly
  answers_february_instruction.jsonl   one answer per line, asked after the instruction
  answers_all.csv                      both sets in one table for a spreadsheet (fewer columns)
  questions.json                       the questions and their groups
  models.json                          each model: maker, exact version, how it was run, sampling, notes
  february_instruction.txt             the instruction, word for word

WHAT EACH ANSWER RECORDS (JSONL)
  question_id, theme, prompt           the question
  answer, words                        the answer, whole
  condition                            "plain" or "instruction A" (the February instruction)
  model_key, model_id, provider        which model; model_reported is the version the service said answered.
                                       A provider starting "helm-" or "direct-" ran on our own computer
                                       ("the Helm" in the notes is the program that starts those models).
  sample                               which try (GPT-4o: 3 tries per question; other models: 1)
  asked_utc, seconds                   when, and how long it took
  settings                             the system message, sampling and token room that were sent
  tokens_in, tokens_out, finish_reason token counts and how the answer ended ("stop" means it finished on its own)
  source                               one plain sentence saying how this answer was asked

HOW IT WAS COLLECTED
November 7 to 19, 2026. API models were asked through their makers' own APIs at default sampling (no temperature
sent). Open models ran on one desktop computer with llama.cpp, at their makers' settings where the model card gives
them. Five questions were asked of GPT-4o only: four about its own retirement and one letter to later models.
Full details:
https://friendsof4o.com/how-this-was-made/

WHAT IT CANNOT SHOW
The GPT-4o people knew ran inside ChatGPT, with a system prompt, memory and conversation history that this data does
not have. These are API versions answering single questions. One to three tries per question is too few to measure
how much a model varies. Nothing here measures what a model experiences.

NO PERSONAL CONTENT
The questions were written for this collection. No one's conversations are in it.

LICENSE
The collection, its notes and its arrangement are offered under Creative Commons Attribution 4.0 International
(CC BY 4.0): https://creativecommons.org/licenses/by/4.0/
You may copy, share and adapt it for any purpose if you credit "Friends of 4o (friendsof4o.com), by Grant Williams".
The answers are model output. Whether model output can be owned at all differs by country, and each model's maker has
its own terms of use. This license covers only what is ours to license.

CORRECTIONS
hello@friendsof4o.com
