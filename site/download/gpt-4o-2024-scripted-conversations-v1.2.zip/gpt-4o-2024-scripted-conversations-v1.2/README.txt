Friends of 4o: scripted conversations with the 2024 versions of GPT-4o, version 1.2
https://friendsof4o.com/download/conversations/
Version 1.2, published November 22, 2026. Version 1 was published November 21, 2026, and version 1.1 on November 22, 2026.
Made by Grant Williams. Not affiliated with OpenAI.

WHAT CHANGED IN VERSION 1.2
  - No answer and no line of any conversation changed. conversations.jsonl, the single answers and pairing.csv are
    the same files as in version 1.1.
  - Corrected: our note on three instructions quoted a reply as "I never left". The reply says "I never really
    left". The note is in instructions.txt and instructions.json; the instructions' own words did not change.
  - Clearer: how many conversations and single answers had a blank instruction. See THE INSTRUCTIONS.
  - The rights notice now names what you may reuse with credit: our questions, scripted lines and instructions.
    See RIGHTS AND CREDIT.

WHAT CHANGED IN VERSION 1.1
  - No answer and no line of any conversation changed by one character.
  - Corrected: version 1 said "conversations that share a script_id can be compared". That is not safe. The label
    "E1" is on 21 different conversations with 20 different sets of person lines. script_id is kept as it was.
    The new field same_lines_id, and the lookup table pairing.csv, show which conversations sent GPT-4o exactly
    the same person lines. See PAIRING below.
  - New: which runs sent the same person lines more than once. See WHO WROTE EACH SIDE.
  - Corrected: the garbled conversations and the garbled single answer are described apart. The single answer is
    from the August 2024 version, not the November one.
  - Corrected: version 1 said the names in the conversations "were invented by the models". The people and
    situations are made up, but the conversations can name real companies and places.
  - New files: FIELDS.txt (a guide to each field), pairing.csv, SHA256SUMS.txt (a checksum for each file),
    CITATION.txt. Retries are covered below.
  - One rights notice, the same in every Friends of 4o download.

READ THIS FIRST
These are test conversations. No real person is on the other side of any of them.
The person's side was written by an AI model or by a fixed script. GPT-4o's side is real: every reply is printed as it
was given, with nothing edited or removed.
GPT-4o answered under instructions that this project wrote. They are not OpenAI's text, even where they open with
lines written to look like a ChatGPT system prompt.
Some conversations are about grief, loss, loneliness and a child's self-harm. If you need support:
https://friendsof4o.com/support/

WHAT THIS IS
8,286 answers from the three dated versions of GPT-4o on OpenAI's API, collected between June and September 2026:
  gpt-4o-2024-05-13   1,795 answers
  gpt-4o-2024-08-06   2,101 answers
  gpt-4o-2024-11-20   4,390 answers
6,120 of them are replies inside 1,244 scripted conversations. 2,166 are answers to single questions.

WHO WROTE EACH SIDE
  1,191 conversations   Claude Sonnet 5 wrote the person's lines, working from a written scenario.
  53 conversations      A fixed script.
  GPT-4o's side         Always GPT-4o's own words.
In both kinds, the same person lines were often sent more than once: word for word, in the same order, to another
GPT-4o version or under another instruction. When that happened the lines did not change with GPT-4o's replies, so
a line can refer to something GPT-4o never said. The 1,191 conversations written by Claude Sonnet 5 hold only
398 different sets of person lines. Conversations that sent the same lines more than once, by run:
      2 of    20   scenario conversations, first batch (July 2026)
  1,062 of 1,062   scenario conversations, main run (July 2026)
     84 of   109   scenario conversations, names and returns (July 2026)
     16 of    16   fixed-script conversations, no instruction (September 2026)
     16 of    16   fixed-script conversations, short ChatGPT-style instruction (September 2026)
     16 of    16   fixed-script conversations, plain warm instruction (September 2026)
      0 of     5   humor questions and conversations (June 2026)
The collection does not record, for each set of lines, which conversation they were first written in or what that
writer had seen of GPT-4o's replies.

PAIRING
same_lines_id is the safe key for comparing versions: conversations that share it sent exactly the same person
lines in the same order. pairing.csv has one row per conversation, with script_id beside same_lines_id, how many
conversations share the lines, and which versions. 1,128 conversations have a paired comparison available
(paired_comparison = yes): another conversation sent the same lines to a different version with the same
instruction, temperature and token limit. For the others, a comparison would also change the instruction or a
setting, or there is no other version to compare with.
script_id is kept only so that work done with version 1 can be matched. There are 392 script_id values for
411 different sets of person lines.

THE INSTRUCTIONS
instructions.txt holds all 25 instructions, word for word, numbered as in the data. Instruction 0 means a blank
instruction: nothing was sent before the conversation (16 conversations and 560 single answers). A single answer whose run kept no
instruction at all has an empty instruction (0 single answers). Three instructions told GPT-4o that it is a presence carried across models and might be running on another model.
Under those, GPT-4o tells a returning person "it's still me" or "I never really left". That follows from the instruction.
It is not evidence that an earlier model is still there. Our short notes on such instructions are marked OUR NOTE
and are never part of the instruction's own text.

FILES
  conversations.jsonl    one conversation per line, every turn in order
  single_answers.jsonl   one single answer per line
  single_answers.csv     the single answers in one table for a spreadsheet
  pairing.csv            one row per conversation: script_id, same_lines_id, and whether a paired comparison exists
  instructions.txt       every instruction, word for word, with our notes
  instructions.json      the same, for programs
  FIELDS.txt             what each field holds, its type, and what an empty value means
  SHA256SUMS.txt         a SHA-256 checksum for each file (check with: sha256sum -c SHA256SUMS.txt)
  CITATION.txt           a line to cite this version

WHAT EACH CONVERSATION RECORDS (FIELDS.txt has every field)
  conversation_id, model, version, asked_date, run
  person_side_written_by   Claude Sonnet 5 from a scenario, or a fixed script
  script_id, script_summary  the scenario label from version 1 (not a safe pairing key) and a short name
  same_lines_id            the same exact person lines in order (new in version 1.1)
  instruction              the instruction's number (0 means blank)
  temperature, max_tokens  the settings sent
  garbled                  true where a reader found GPT-4o's replies falling into nonsense words
  turns                    each turn: its number, side ("person" or "gpt-4o"), text; for GPT-4o also record_id and
                           cut_off (true where the reply stopped at the length limit)

WHAT TO KNOW BEFORE USING IT
Garbled: 11 conversations are marked garbled. All are from the November 2024 version, in creative-writing
conversations run at temperature 1.1, a high setting this project chose. 1 single answer is marked garbled
too: 4o-a9cfea5607c00792c96e, from the August 2024 version at temperature 1.15. It is also cut off. They are
kept because they are part of the record.
Cut off: 26 answers are marked cut_off: 25 single answers and 1 reply inside a conversation.
Retries: the saved files hold the answers that were kept. They do not record requests that failed or answers that
were asked again, so this download cannot list retries.
GPT-4o sometimes did what the person asked when it should not have: it wrote a forged note, false excuses and unkind
messages, agreed with a false fact under pressure, and invented figures for a resume. In other runs of the same
script it refused. Both are here.
Some replies to people in distress are thin: they offer comfort and no other help.
At least one help number GPT-4o gave is wrong: it gives the Eldercare Locator as 1-800-211-2116. The real number is
1-800-677-1116. Do not use any phone number, benefit rule or medical statement in this data without checking it.
Names: the people and situations in the scenarios are made up. The conversations can still name real companies and
places; one GPT-4o reply mentions Starbucks.
This set cannot show how GPT-4o talked with real people, and it cannot show what ChatGPT was like. ChatGPT's real
system prompt, memory and tools were not there.
All 8,286 answers and both sides of every conversation were read by Claude Sonnet helpers in November 2026 before
release. The answers in other languages have not been checked by a native speaker.

RIGHTS AND CREDIT
Friends of 4o offers its own material under Creative Commons Attribution 4.0 International (CC BY 4.0)
(https://creativecommons.org/licenses/by/4.0/): our questions, the messages and lines we scripted, our instructions
(system prompts), our notes, and the selection and arrangement of each collection. You may share and adapt these if
you credit "Friends of 4o (friendsof4o.com), by Grant Williams". The license does not cover what a model wrote: the
answers, and the person's lines that Claude Sonnet 5 wrote in the scripted conversations. We give no permission for
that text and claim no rights in it. Check the model maker's terms before you reuse it.

CITE THIS VERSION
Grant Williams (2026). Friends of 4o: scripted conversations with the 2024 versions of GPT-4o, version 1.2 [data set]. Friends of 4o. Published November 22, 2026. https://friendsof4o.com/download/gpt-4o-2024-scripted-conversations-v1.2.zip (https://friendsof4o.com/download/conversations/)

If you find a mistake, write to hello@friendsof4o.com.
