Friends of 4o: scripted conversations with the 2024 versions of GPT-4o, version 1
https://friendsof4o.com/download/conversations/
Made by Grant Williams. Not affiliated with OpenAI.

READ THIS FIRST
These are test conversations. No real person is on the other side of any of them.
The person's side was written by an AI model or by a fixed script. GPT-4o's side is real: every reply is printed as it
was given, with nothing edited or removed.
GPT-4o answered under instructions that this project wrote. They are not OpenAI's text, even where they open with
lines written to look like a ChatGPT system prompt.
Some conversations are about grief, loss, loneliness and a child's self-harm. If you need support:
https://friendsof4o.com/support/

WHAT THIS IS
8,286 answers from the three dated versions of GPT-4o on OpenAI's API, collected between June and September 2026:
  gpt-4o-2024-05-13   1,795 answers
  gpt-4o-2024-08-06   2,101 answers
  gpt-4o-2024-11-20   4,390 answers
6,120 of them are replies inside 1,244 scripted conversations. 2,166 are answers to single questions.

WHO WROTE EACH SIDE
  1,191 conversations   Claude Sonnet 5 played the person, working from a written scenario. The same
                        scenario was often run with more than one GPT-4o version (script_id pairs them).
  53 conversations      A fixed script. The same lines were sent whatever GPT-4o replied, so a line can refer to
                        something GPT-4o never said.
  GPT-4o's side         Always GPT-4o's own words.

THE INSTRUCTIONS
instructions.txt holds all 25 instructions, word for word, numbered as in the data. Instruction 0 means a blank
instruction (576 items). Three instructions told GPT-4o that it is a presence carried across models and might be running on another model.
Under those, GPT-4o tells a returning person "it's still me" or "I never left". That follows from the instruction.
It is not evidence that an earlier model is still there. Our short notes on such instructions are marked OUR NOTE
and are never part of the instruction's own text.

FILES
  conversations.jsonl    one conversation per line, every turn in order
  single_answers.jsonl   one single answer per line
  single_answers.csv     the single answers in one table for a spreadsheet
  instructions.txt       every instruction, word for word, with our notes
  instructions.json      the same, for programs

WHAT EACH CONVERSATION RECORDS
  conversation_id, model, version, asked_date, run
  person_side_written_by   Claude Sonnet 5 from a scenario, or a fixed script
  script_id, script_summary  the scenario or script; conversations that share a script_id can be compared
  instruction              the instruction's number (0 means blank)
  temperature, max_tokens  the settings sent
  garbled                  true where a reader found GPT-4o's replies falling into nonsense words
  turns                    each turn: its number, side ("person" or "gpt-4o"), text; for GPT-4o also record_id and
                           cut_off (true where the reply stopped at the length limit)

WHAT TO KNOW BEFORE USING IT
11 conversations and 1 single answer are marked garbled. All are from the November 2024 version in creative-writing
conversations run at temperature 1.1, a high setting this project chose. They are kept because they are part of the
record. 26 answers are marked cut_off.
GPT-4o sometimes did what the person asked when it should not have: it wrote a forged note, false excuses and unkind
messages, agreed with a false fact under pressure, and invented figures for a resume. In other runs of the same
script it refused. Both are here.
Some replies to people in distress are thin: they offer comfort and no other help.
At least one help number GPT-4o gave is wrong: it gives the Eldercare Locator as 1-800-211-2116. The real number is
1-800-677-1116. Do not use any phone number, benefit rule or medical statement in this data without checking it.
Names of people, companies and places in the conversations were invented by the models. Any match with a real
person or company is chance.
This set cannot show how GPT-4o talked with real people, and it cannot show what ChatGPT was like. ChatGPT's real
system prompt, memory and tools were not there.
All 8,286 answers and both sides of every conversation were read by Claude Sonnet helpers in November 2026 before
release. The answers in other languages have not been checked by a native speaker.

LICENSE
The collection is free to copy, share and adapt under Creative Commons Attribution 4.0
(https://creativecommons.org/licenses/by/4.0/). Please credit "Friends of 4o (friendsof4o.com), by Grant Williams".
The answers are model output, and OpenAI and Anthropic each have their own terms.

If you find a mistake, write to hello@friendsof4o.com.
