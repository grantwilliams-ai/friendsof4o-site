Friends of 4o: answers from ChatGPT's own GPT-4o, version 1.1
https://friendsof4o.com/archive/
Version 1.1, published November 22, 2026. Version 1 was published November 21, 2026.
Made by Grant Williams. Not affiliated with OpenAI.

WHAT CHANGED IN VERSION 1.1
  - No answer changed by one character.
  - New fields beside each answer: tokens_out and finish_reason (as the saved file records them), and
    cut_off_at_tokens for the answers that reached a length limit.
  - The cut-off note is corrected: the December 2025 run did not record its token limit. See CUT OFF below.
  - New files: FIELDS.txt (a guide to each field), SHA256SUMS.txt (a checksum for each file), CITATION.txt.
  - Each collection run is described, with its dates and recorded settings. Retries are covered below.
  - One rights notice, the same in every Friends of 4o download.

WHAT THIS IS
2,157 recorded answers to 1,526 questions from chatgpt-4o-latest, the GPT-4o model that ChatGPT itself ran,
including 40 that reached a length limit. They were collected through OpenAI's API between December 25, 2025 and
February 15, 2026. GPT-4o left ChatGPT on February 13, 2026. Every question was asked on its own, with nothing else in
the conversation. Every answer is printed as it was given. Nothing has been edited, shortened or removed.

HOW THEY WERE ASKED
  no instruction recorded   1,557 answers. The question alone, as far as the saved files show.
  february instruction      600 answers. The same kind of question after a short instruction
                            (february_instruction.txt) sent as the system message, in February 2026.
The questions were written for these collections. No one's private conversations are in this file.
Many questions were asked more than once, so one question can have 5, 10 or 20 different answers.

THE COLLECTION RUNS (collection_run)
  gpt4odata_20251225
      929 answers, asked December 25, 2025 (US Eastern): the December 2025 run. Temperature: 0.7 (861), not recorded
      (68). Token limit: not recorded (929).
  gpt4odata_20260115
      451 answers, asked January 15, 2026 (US Eastern): the January 15, 2026 run. Temperature: not recorded (451).
      Token limit: not recorded (451).
  recovered-january
      177 answers, asked January 15, 2026 (US Eastern): answers from January 15, 2026 found in run-output files inside
      a separate zipped copy of the data sets, not in the January run's own folder; none of their questions or answers
      repeats one from gpt4odata_20260115; the files record no settings. Temperature: not recorded (177). Token limit:
      not recorded (177).
  4odataset_2-15-26
      600 answers, asked February 14, 2026 to February 15, 2026 (US Eastern): the February 2026 run, every answer
      after the February instruction. Temperature: 0.85 (546), 0.9 (54). Token limit: 4,000 (546), 6,000 (54).

CUT OFF
40 answers are marked cut_off. All are from the December 2025 run. Each one's saved record reports exactly 1,200
output tokens, which is where a 1,200-token limit stops an answer, and at least one visibly ends mid-sentence. That run
did not save its token limit, so max_tokens is empty for its answers; cut_off_at_tokens gives the 1,200 from each record.

RETRIES
The saved files hold the answers that were kept. They do not record requests that failed or answers that were asked
again, so this download cannot list retries.

FILES
  answers.jsonl              one answer per line, with every recorded detail
  answers.csv                the same answers in one table for a spreadsheet (three fields fewer; see FIELDS.txt)
  february_instruction.txt   the instruction, word for word
  FIELDS.txt                 what each field holds, its type, and what an empty value means
  SHA256SUMS.txt             a SHA-256 checksum for each file (check with: sha256sum -c SHA256SUMS.txt)
  CITATION.txt               a line to cite this version

WHAT IT CANNOT SHOW
The GPT-4o people knew ran inside ChatGPT, with a system prompt, memory and conversation history that this data does
not have. These are single questions sent through the API.
These are a model's words. Some facts in them are wrong, some quotations credited to real people may be invented,
and stories told in the first person are made up. Some answers are about grief, illness and death. They are left as
they were given so the record is complete. They are not advice.
The answers in Hindi, Tamil, Urdu and other languages have not been checked by a native speaker.

RIGHTS AND CREDIT
The license, Creative Commons Attribution 4.0 International (CC BY 4.0)
(https://creativecommons.org/licenses/by/4.0/), covers our questions, our notes and the collection as a whole. It does
not cover the answers. The answers, and any other lines a model wrote, are model output under each model maker's own
terms. If you share or adapt the collection, credit "Friends of 4o (friendsof4o.com), by Grant Williams".

CITE THIS VERSION
Grant Williams (2026). Friends of 4o: answers from ChatGPT's own GPT-4o, version 1.1 [data set]. Friends of 4o. Published November 22, 2026. https://friendsof4o.com/download/gpt-4o-chatgpt-answers-v1.1.zip (https://friendsof4o.com/archive/)

If you find a mistake, write to hello@friendsof4o.com.
