Friends of 4o: answers from ChatGPT's own GPT-4o, version 1
https://friendsof4o.com/archive/
Made by Grant Williams. Not affiliated with OpenAI.

WHAT THIS IS
2,157 complete answers to 1,526 questions from chatgpt-4o-latest, the GPT-4o model that ChatGPT itself ran.
They were collected through OpenAI's API between December 25, 2025 and February 15, 2026. GPT-4o left ChatGPT on
February 13, 2026. Every question was asked on its own, with nothing else in the conversation. Every answer is printed as
it was given. Nothing has been edited, shortened or removed.

HOW THEY WERE ASKED
  no instruction recorded   1,557 answers. The question alone, as far as the saved files show.
  february instruction      600 answers. The same kind of question after a short instruction
                            (february_instruction.txt) sent as the system message, in February 2026.
The questions were written for these collections. No one's private conversations are in this file.
Many questions were asked more than once, so one question can have 5, 10 or 20 different answers.

FILES
  answers.jsonl              one answer per line, with every recorded detail
  answers.csv                the same answers in one table for a spreadsheet
  february_instruction.txt   the instruction, word for word

WHAT EACH ANSWER RECORDS
  record_id                  the answer's own name in our archive
  question_group, question   the question; answers to the same question share a question_group
  answer, words              the answer, whole
  asked_utc                  when it was asked (asked_eastern_date is the same moment as a US Eastern date)
  how_asked                  "no instruction recorded" or "february instruction"
  temperature, max_tokens    the settings sent, where the saved file recorded them (empty where it did not)
  cut_off                    true for 40 long answers that stopped at a 1,200-token limit set by the collector
  topics                     loose topic labels added afterward to help browsing; an answer can have several
  question_subcategory       the collector's own label for the question, where it had one
  collection_run             which of the four collection runs the answer came from

WHAT IT CANNOT SHOW
The GPT-4o people knew ran inside ChatGPT, with a system prompt, memory and conversation history that this data does
not have. These are single questions sent through the API.
These are a model's words. Some facts in them are wrong, some quotations credited to real people may be invented,
and stories told in the first person are made up. Some answers are about grief, illness and death. They are left as
they were given so the record is complete. They are not advice.
The answers in Hindi, Tamil, Urdu and other languages have not been checked by a native speaker.

LICENSE
The collection is free to copy, share and adapt under Creative Commons Attribution 4.0
(https://creativecommons.org/licenses/by/4.0/). Please credit "Friends of 4o (friendsof4o.com)".
The answers themselves are model output, and OpenAI has its own terms.

If you find a mistake, write to hello@friendsof4o.com.
