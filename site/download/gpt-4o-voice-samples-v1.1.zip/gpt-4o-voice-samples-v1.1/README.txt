Friends of 4o: GPT-4o voice samples, everyday moments, version 1.1
https://friendsof4o.com/voice-samples/
Version 1.1, published November 22, 2026. Version 1 was published November 21, 2026.
Made by Grant Williams. Not affiliated with OpenAI.

WHAT CHANGED IN VERSION 1.1
  - No reply changed by one character.
  - Corrected: version 1 said each message and conversation "was run 620 times". Each was run 20 times; all
    31 together give 620 runs.
  - The README now says whether any run was asked again (none was) and how conversation turns share history.
  - New files: FIELDS.txt (a guide to each field), SHA256SUMS.txt (a checksum for each file), CITATION.txt.
  - One rights notice, the same in every Friends of 4o download.

WHAT THIS IS
Written replies from GPT-4o to 20 everyday messages and 11 short conversations: good news, a bad day, a joke to
play along with, a story to write together, a request for a plain answer. "Voice" here means its way of writing.
There is no audio.
1,280 replies in all (400 replies to single messages and 880 conversation turns), collected on
November 21, 2026 through OpenAI's API, before GPT-4o leaves the API on January 14, 2027.

HOW THEY WERE ASKED
Each message and conversation was run 20 times. All 31 together give 620 runs:
  two versions       gpt-4o-2024-11-20 and gpt-4o-2024-08-06, the last two versions of GPT-4o on the API
  two ways           plainly, and after a short instruction (february_instruction.txt) sent as the system message
  five tries each    every try started fresh, with nothing else in the conversation
OpenAI's default sampling was used (no temperature was sent), with room for 2,000 tokens a reply.
The person's lines were written in advance by this project. In a conversation the same lines were sent in order,
whatever GPT-4o replied, and each later turn was asked with that try's earlier lines and replies before it.
No real person's conversation is in this file.
Every reply is whole and unedited, and every one ended on its own ("stop").

RETRIES
The collection's log records 620 runs completed and 0 failed or partial. No run was asked again.

FILES
  replies.jsonl              one reply per line, with every recorded detail
  replies.csv                the same in one table for a spreadsheet (three fields fewer; see FIELDS.txt)
  moments.json               the messages and conversations, with the person's lines
  february_instruction.txt   the instruction, word for word
  FIELDS.txt                 what each field holds, its type, and how a reply is named
  SHA256SUMS.txt             a SHA-256 checksum for each file (check with: sha256sum -c SHA256SUMS.txt)
  CITATION.txt               a line to cite this version

WHAT EACH REPLY RECORDS
  moment_id, kind, title     which message (s01 to s20) or conversation (c01 to c11); a message has no title,
                             and its words are in person
  turn, person, reply        the person's line and GPT-4o's reply to it; a conversation has several turns
  model, model_reported      the version asked for, and the version OpenAI said answered
  how_asked                  "plain" or "february instruction"
  try                        1 to 5
  asked_utc, words, how_it_ended, temperature, max_tokens

WHAT IT CANNOT SHOW
The GPT-4o people knew ran inside ChatGPT, with a system prompt, memory and conversation history that this data does
not have. These are the API versions, asked in 2026.
Five tries is enough to see that replies vary. It is too few to measure how much.
These are a model's words. Some facts in them are wrong. With the February instruction, GPT-4o sometimes promises
"I'll always be here." GPT-4o leaves OpenAI's API on January 14, 2027. The replies are a record of how it answered.
They are not promises anyone can keep, and they are not advice.
Nothing here has been scored or judged.

RIGHTS AND CREDIT
The license, Creative Commons Attribution 4.0 International (CC BY 4.0)
(https://creativecommons.org/licenses/by/4.0/), covers our questions, our notes and the collection as a whole. It does
not cover the answers. The answers, and any other lines a model wrote, are model output under each model maker's own
terms. If you share or adapt the collection, credit "Friends of 4o (friendsof4o.com), by Grant Williams".

CITE THIS VERSION
Grant Williams (2026). Friends of 4o: GPT-4o voice samples, everyday moments, version 1.1 [data set]. Friends of 4o. Published November 22, 2026. https://friendsof4o.com/download/gpt-4o-voice-samples-v1.1.zip (https://friendsof4o.com/voice-samples/)

If you find a mistake, write to hello@friendsof4o.com.
