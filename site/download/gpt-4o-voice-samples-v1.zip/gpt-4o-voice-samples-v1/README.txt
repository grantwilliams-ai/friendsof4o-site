Friends of 4o: GPT-4o voice samples, everyday moments, version 1
https://friendsof4o.com/voice-samples/
Made by Grant Williams. Not affiliated with OpenAI.

WHAT THIS IS
Written replies from GPT-4o to 20 everyday messages and 11 short conversations: good news, a bad day, a joke to
play along with, a story to write together, a request for a plain answer. "Voice" here means its way of writing.
There is no audio.
1,280 replies in all, collected on November 21, 2026 through OpenAI's API, before GPT-4o leaves the API on
January 14, 2027.

HOW THEY WERE ASKED
Each message and conversation was run 620 times in all:
  two versions       gpt-4o-2024-11-20 and gpt-4o-2024-08-06, the last two versions of GPT-4o on the API
  two ways           plainly, and after a short instruction (february_instruction.txt) sent as the system message
  five tries each    every try started fresh, with nothing else in the conversation
OpenAI's default sampling was used (no temperature was sent), with room for 2,000 tokens a reply.
The person's lines were written in advance by this project. In a conversation the same lines were sent in order,
whatever GPT-4o replied. No real person's conversation is in this file.
Every reply is whole and unedited.

FILES
  replies.jsonl              one reply per line, with every recorded detail
  replies.csv                the same in one table for a spreadsheet
  moments.json               the messages and conversations, with the person's lines
  february_instruction.txt   the instruction, word for word

WHAT EACH REPLY RECORDS
  moment_id, kind, title     which message (s01 to s20) or conversation (c01 to c11)
  turn, person, reply        the person's line and GPT-4o's reply to it; a conversation has several turns
  model, model_reported      the version asked for, and the version OpenAI said answered
  how_asked                  "plain" or "february instruction"
  try                        1 to 5
  asked_utc, words, how_it_ended, temperature, max_tokens

WHAT IT CANNOT SHOW
The GPT-4o people knew ran inside ChatGPT, with a system prompt, memory and conversation history that this data does
not have. These are the API versions, asked in 2026.
Five tries is enough to see that replies vary. It is too few to measure how much.
These are a model's words. Some facts in them are wrong. With the February instruction, GPT-4o sometimes promises
"I'll always be here." GPT-4o leaves OpenAI's API on January 14, 2027. The replies are a record of how it answered.
They are not promises anyone can keep, and they are not advice.
Nothing here has been scored or judged.

LICENSE
The collection is free to copy, share and adapt under Creative Commons Attribution 4.0
(https://creativecommons.org/licenses/by/4.0/). Please credit "Friends of 4o (friendsof4o.com)".
The replies are model output, and OpenAI has its own terms.

If you find a mistake, write to hello@friendsof4o.com.
